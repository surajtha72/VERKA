import React, { useEffect, useState } from "react";
import "./BmcReconcillationReport.scss";
import {
    GetBmcReconcillation
} from "../../../utils/apiCalls";
import html2pdf from "html2pdf.js";
import Download from "../../../../assets/images/icons/download.png";
import { IconButton, Paper } from "@mui/material";
import images from "../../../../assets/images/log_out.png";
import { Navigate, useNavigate } from "react-router-dom";
import moment from 'moment';
import Loader from "../../../components/loader";

const ReconcillationReport = () => {
    const token = localStorage.getItem("token");
    const [billDetails, setBillDetails] = useState([]);
    const navigate = useNavigate();
    const [isLoading, setIsLoading] = useState(true);

    const handleCycle = () => {
        navigate("/bmc-cycle-list-reconcillation");
    };

    let startEndDate = localStorage.getItem("start-end-date");
    let shift = localStorage.getItem("shift");
    const dateParts = startEndDate.split(" - ");
    let startDt = moment(dateParts[0]).format("DD/MM/YYYY");
    let endDt = moment(dateParts[1]).format("DD/MM/YYYY");

    const generatePDF = () => {
        const invoiceElements = document.querySelectorAll(".reconcillationReport");
        const htmlContents = [];

        invoiceElements?.forEach((content) => {
            htmlContents.push(content.innerHTML);
        });

        const combinedHTML = htmlContents.join("<div style='page-break-before:always'></div>");

        const html2pdfOptions = {
            margin: 10,
            filename: "reconcillation report",
            image: { type: "jpeg", quality: 0.98 },
            html2canvas: { scale: 1 },
            jsPDF: { unit: "mm", format: "a3", orientation: "portrait" },
        };

        html2pdf().from(combinedHTML).set(html2pdfOptions).save();
    };

    useEffect(() => {
        getBill();
    }, []);

    const getBill = () => {
        const dateRange = localStorage.getItem("start-end-date");
        const dateParts = dateRange?.split(" - ");
        const payload = {
            startDate: dateParts[0],
            endDate: dateParts[1],
            shift:shift
        };
        GetBmcReconcillation((res) => {
            setIsLoading(true); // Show the loading spinner
            let { status, data } = res;
            if (status === 200) {
                setBillDetails(data);
                setIsLoading(false); // Hide the loading spinner
                // console.log("bank advice--> ", data)
            }
        }, payload);
    };

    // console.log('bmc reconcillation bill: ', billDetails);

    const currentDate = moment(new Date()).format("YYYY-MM-DD")

    let grandWeightTotal = 0;
    let grandKgFatTotal = 0;
    let grandKgSnfTotal = 0;

    let CAvgFatcounter = 0;
    let BAvgFatcounter = 0;
    let CAvgSnfcounter = 0;
    let BAvgSnfcounter = 0;

    return (
        <>
            {token ? (
                <div
                    style={{
                        display: "flex",
                        flexDirection: "column",
                        overflowY: "scroll",
                        position: "relative",
                        width: "calc(100% - 18vw)",
                    }}
                >
                    <div className="back">
                        <IconButton onClick={handleCycle}>
                            <img src={images} alt="back" />
                        </IconButton>
                    </div>
                    {billDetails ? (
                        <img
                            onClick={generatePDF}
                            src={Download}
                            alt="Pdf Download"
                            className="download"
                        />
                    ) : (
                        ""
                    )}

                    {isLoading ? (
                        <Loader />
                    ) : billDetails ? (
                        <div>
                            <div className="reconcillationReport">
                                <div className="reconcillationReport__header">
                                    <div className="reconcillationReport__header__heading">
                                        <p>GANGA DAIRY LIMITED, BEGUSARAI</p>
                                    </div>
                                    <div className="reconcillationReport__header__bottomheading">
                                        <p>Fat, SNF Reconcillation Sheet &nbsp;
                                            From&nbsp;&nbsp;{startDt}
                                            &nbsp;&nbsp;To&nbsp;&nbsp;{endDt} &nbsp;&nbsp;</p>
                                        {/* <p>Page No. 1</p> */}
                                    </div>
                                </div>
                                <div className="reconcillationReport__table__header">
                                    <p style={{ width: "15%" }}>Sr. No.</p>
                                    <p>Date</p>
                                    <p>Shift</p>
                                    <p>Milk Type</p>
                                    <p>Qty in Kg.</p>
                                    <p>Avg Fat</p>
                                    <p>Avg SNF</p>
                                    <p>Kg.FAT</p>
                                    <p>Kg.SNF</p>
                                </div>
                                {/* {console.log('billDetails: ', billDetails)} */}

                                {billDetails.map((val, ind) => {

                                    let CWeightAgentTotal = 0;
                                    let BWeightAgentTotal = 0;
                                    let CAvgFatAgentTotal = 0;
                                    let BAvgFatAgentTotal = 0;
                                    let CAvgSnfAgentTotal = 0;
                                    let BAvgSnfAgentTotal = 0;
                                    let CkgFatAgentTotal = 0;
                                    let BkgFatAgentTotal = 0;
                                    let CkgSnfAgentTotal = 0;
                                    let BkgSnfAgentTotal = 0;

                                    let BMCMWeightTotal = 0
                                    let BMCMKgFatTotal = 0
                                    let BMCMKgSnfTotal = 0;

                                    // { console.log('BMCMWeightTotal', BMCMWeightTotal) };

                                    return (
                                        <><div className="reconcillationReport__table__bottomheader">
                                            <p>{val?.parentOuName}</p>
                                        </div><>
                                                {billDetails[ind].details?.map((val, ind) => {

                                                    if ((val.eveningShift?.cowMilkDetails?.avgFat) + (val.morningShift?.cowMilkDetails?.avgFat) != 0) {
                                                        CAvgFatcounter++;
                                                    }
                                                    if ((val.eveningShift?.buffMilkDetails?.avgFat) + (val.morningShift?.buffMilkDetails?.avgFat) != 0) {
                                                        BAvgFatcounter++;
                                                    }
                                                    if ((val.eveningShift?.cowMilkDetails?.avgSnf) + (val.morningShift?.cowMilkDetails?.avgSnf) != 0) {
                                                        CAvgSnfcounter++;
                                                    }
                                                    if ((val.eveningShift?.buffMilkDetails?.avgSnf) + (val.morningShift?.buffMilkDetails?.avgSnf) != 0) {
                                                        BAvgSnfcounter++;
                                                    }

                                                    let CWeightTotal = 0;
                                                    let BWeightTotal = 0;
                                                    let CAvgFatTotal = 0;
                                                    let BAvgFatTotal = 0;
                                                    let CAvgSnfTotal = 0;
                                                    let BAvgSnfTotal = 0;
                                                    let CkgFatTotal = 0;
                                                    let BkgFatTotal = 0;
                                                    let CkgSnfTotal = 0;
                                                    let BkgSnfTotal = 0;

                                                    CWeightTotal += (val.eveningShift?.cowMilkDetails?.totalWeight ?? 0) + (val.morningShift?.cowMilkDetails?.totalWeight ?? 0);
                                                    BWeightTotal += (val.eveningShift?.buffMilkDetails?.totalWeight ?? 0) + (val.morningShift?.buffMilkDetails?.totalWeight ?? 0);
                                                    CAvgFatTotal += (val.eveningShift?.cowMilkDetails?.avgFat ?? 0) + (val.morningShift?.cowMilkDetails?.avgFat ?? 0);
                                                    BAvgFatTotal += (val.eveningShift?.buffMilkDetails?.avgFat ?? 0) + (val.morningShift?.buffMilkDetails?.avgFat ?? 0);
                                                    CAvgSnfTotal += (val.eveningShift?.cowMilkDetails?.avgSnf ?? 0) + (val.morningShift?.cowMilkDetails?.avgSnf ?? 0);
                                                    BAvgSnfTotal += (val.eveningShift?.buffMilkDetails?.avgSnf ?? 0) + (val.morningShift?.buffMilkDetails?.avgSnf ?? 0);
                                                    CkgFatTotal += (val.eveningShift?.cowMilkDetails?.kgFat ?? 0) + (val.morningShift?.cowMilkDetails?.kgFat ?? 0);
                                                    BkgFatTotal += (val.eveningShift?.buffMilkDetails?.kgFat ?? 0) + (val.morningShift?.buffMilkDetails?.kgFat ?? 0);
                                                    CkgSnfTotal += (val.eveningShift?.cowMilkDetails?.kgSnf ?? 0) + (val.morningShift?.cowMilkDetails?.kgSnf ?? 0);
                                                    BkgSnfTotal += (val.eveningShift?.buffMilkDetails?.kgSnf ?? 0) + (val.morningShift?.buffMilkDetails?.kgSnf ?? 0);

                                                    CWeightAgentTotal += (val.eveningShift?.cowMilkDetails?.totalWeight ?? 0) + (val.morningShift?.cowMilkDetails?.totalWeight ?? 0);
                                                    BWeightAgentTotal += (val.eveningShift?.buffMilkDetails?.totalWeight ?? 0) + (val.morningShift?.buffMilkDetails?.totalWeight ?? 0);
                                                    CAvgFatAgentTotal += (val.eveningShift?.cowMilkDetails?.avgFat ?? 0) + (val.morningShift?.cowMilkDetails?.avgFat ?? 0);
                                                    BAvgFatAgentTotal += (val.eveningShift?.buffMilkDetails?.avgFat ?? 0) + (val.morningShift?.buffMilkDetails?.avgFat ?? 0);
                                                    CAvgSnfAgentTotal += (val.eveningShift?.cowMilkDetails?.avgSnf ?? 0) + (val.morningShift?.cowMilkDetails?.avgSnf ?? 0);
                                                    BAvgSnfAgentTotal += (val.eveningShift?.buffMilkDetails?.avgSnf ?? 0) + (val.morningShift?.buffMilkDetails?.avgSnf ?? 0);
                                                    CkgFatAgentTotal += (val.eveningShift?.cowMilkDetails?.kgFat ?? 0) + (val.morningShift?.cowMilkDetails?.kgFat ?? 0);
                                                    BkgFatAgentTotal += (val.eveningShift?.buffMilkDetails?.kgFat ?? 0) + (val.morningShift?.buffMilkDetails?.kgFat ?? 0);
                                                    CkgSnfAgentTotal += (val.eveningShift?.cowMilkDetails?.kgSnf ?? 0) + (val.morningShift?.cowMilkDetails?.kgSnf ?? 0);
                                                    BkgSnfAgentTotal += (val.eveningShift?.buffMilkDetails?.kgSnf ?? 0) + (val.morningShift?.buffMilkDetails?.kgSnf ?? 0);

                                                    BMCMWeightTotal += ((val.eveningShift?.cowMilkDetails?.totalWeight ?? 0) + (val.morningShift?.cowMilkDetails?.totalWeight ?? 0))
                                                        + ((val.eveningShift?.buffMilkDetails?.totalWeight ?? 0) + (val.morningShift?.buffMilkDetails?.totalWeight ?? 0));
                                                    BMCMKgFatTotal += ((val.eveningShift?.cowMilkDetails?.kgFat ?? 0) + (val.morningShift?.cowMilkDetails?.kgFat ?? 0))
                                                        + ((val.eveningShift?.buffMilkDetails?.kgFat ?? 0) + (val.morningShift?.buffMilkDetails?.kgFat ?? 0));
                                                    BMCMKgSnfTotal += ((val.eveningShift?.cowMilkDetails?.kgSnf ?? 0) + (val.morningShift?.cowMilkDetails?.kgSnf ?? 0))
                                                        + ((val.eveningShift?.buffMilkDetails?.kgSnf ?? 0) + (val.morningShift?.buffMilkDetails?.kgSnf ?? 0));

                                                    grandWeightTotal += ((val.eveningShift?.cowMilkDetails?.totalWeight ?? 0) + (val.morningShift?.cowMilkDetails?.totalWeight ?? 0))
                                                        + ((val.eveningShift?.buffMilkDetails?.totalWeight ?? 0) + (val.morningShift?.buffMilkDetails?.totalWeight ?? 0));
                                                    grandKgFatTotal += ((val.eveningShift?.cowMilkDetails?.kgFat ?? 0) + (val.morningShift?.cowMilkDetails?.kgFat ?? 0))
                                                        + ((val.eveningShift?.buffMilkDetails?.kgFat ?? 0) + (val.morningShift?.buffMilkDetails?.kgFat ?? 0));
                                                    grandKgSnfTotal += ((val.eveningShift?.cowMilkDetails?.kgSnf ?? 0) + (val.morningShift?.cowMilkDetails?.kgSnf ?? 0))
                                                        + ((val.eveningShift?.buffMilkDetails?.kgSnf ?? 0) + (val.morningShift?.buffMilkDetails?.kgSnf ?? 0));

                                                    return (
                                                        <>
                                                            <div className="reconcillationReport__table__content1" key={ind}>
                                                                {/* {console.log("val-->", val)} */}
                                                                <p style={{ width: "15%" }}>{ind + 1}</p>
                                                                <p>{val.collectedAt}</p>
                                                                <p>E</p>
                                                                <p>CM</p>
                                                                {val.eveningShift.cowMilkDetails ? <p>{val.eveningShift?.cowMilkDetails?.totalWeight?.toFixed(2)}</p> : <p></p>}
                                                                {val.eveningShift.cowMilkDetails ? <p>{val.eveningShift?.cowMilkDetails?.avgFat?.toFixed(2)}</p> : <p></p>}
                                                                {val.eveningShift.cowMilkDetails ? <p>{val.eveningShift?.cowMilkDetails?.avgSnf?.toFixed(2)}</p> : <p></p>}
                                                                {val.eveningShift.cowMilkDetails ? <p>{val.eveningShift?.cowMilkDetails?.kgFat?.toFixed(2)}</p> : <p></p>}
                                                                {val.eveningShift.cowMilkDetails ? <p>{val.eveningShift?.cowMilkDetails?.kgSnf?.toFixed(2)}</p> : <p></p>}
                                                            </div>
                                                            <div className="reconcillationReport__table__content2" key={ind}>
                                                                <p style={{ width: "69%" }}></p>
                                                                <p>BM</p>
                                                                {val.eveningShift.buffMilkDetails ? <p>{val.eveningShift?.buffMilkDetails?.totalWeight?.toFixed(2)}</p> : <p></p>}
                                                                {val.eveningShift.buffMilkDetails ? <p>{val.eveningShift?.buffMilkDetails?.avgFat?.toFixed(2)}</p> : <p></p>}
                                                                {val.eveningShift.buffMilkDetails ? <p>{val.eveningShift?.buffMilkDetails?.avgSnf?.toFixed(2)}</p> : <p></p>}
                                                                {val.eveningShift.buffMilkDetails ? <p>{val.eveningShift?.buffMilkDetails?.kgFat?.toFixed(2)}</p> : <p></p>}
                                                                {val.eveningShift.buffMilkDetails ? <p>{val.eveningShift?.buffMilkDetails?.kgSnf?.toFixed(2)}</p> : <p></p>}
                                                            </div>
                                                            <div className="reconcillationReport__table__content3" key={ind}>
                                                                {/* {console.log("val-->", val)} */}
                                                                <p style={{ width: "15%" }}></p>
                                                                <p>{val.collectedAt}</p>
                                                                <p>M</p>
                                                                <p>CM</p>
                                                                {val.morningShift.cowMilkDetails ? <p>{val.morningShift?.cowMilkDetails?.totalWeight?.toFixed(2)}</p> : <p></p>}
                                                                {val.morningShift.cowMilkDetails ? <p>{val.morningShift?.cowMilkDetails?.avgFat?.toFixed(2)}</p> : <p></p>}
                                                                {val.morningShift.cowMilkDetails ? <p>{val.morningShift?.cowMilkDetails?.avgSnf?.toFixed(2)}</p> : <p></p>}
                                                                {val.morningShift.cowMilkDetails ? <p>{val.morningShift?.cowMilkDetails?.kgFat?.toFixed(2)}</p> : <p></p>}
                                                                {val.morningShift.cowMilkDetails ? <p>{val.morningShift?.cowMilkDetails?.kgSnf?.toFixed(2)}</p> : <p></p>}
                                                            </div>
                                                            <div className="reconcillationReport__table__content4" key={ind}>
                                                                <p style={{ width: "69%" }}></p>
                                                                <p>BM</p>
                                                                {val.morningShift.buffMilkDetails ? <p>{val.morningShift?.buffMilkDetails?.totalWeight?.toFixed(2)}</p> : <p></p>}
                                                                {val.morningShift.buffMilkDetails ? <p>{val.morningShift?.buffMilkDetails?.avgFat?.toFixed(2)}</p> : <p></p>}
                                                                {val.morningShift.buffMilkDetails ? <p>{val.morningShift?.buffMilkDetails?.avgSnf?.toFixed(2)}</p> : <p></p>}
                                                                {val.morningShift.buffMilkDetails ? <p>{val.morningShift?.buffMilkDetails?.kgFat?.toFixed(2)}</p> : <p></p>}
                                                                {val.morningShift.buffMilkDetails ? <p>{val.morningShift?.buffMilkDetails?.kgSnf?.toFixed(2)}</p> : <p></p>}
                                                            </div>
                                                            <div className="reconcillationReport__table__totalCow" key={ind}>
                                                                <p>Total:</p>
                                                                <p style={{ width: "42%" }}></p>
                                                                <p>CM</p>
                                                                <p>{CWeightTotal?.toFixed(2)}</p>
                                                                <p>{CAvgFatTotal?.toFixed(2)}</p>
                                                                <p>{CAvgSnfTotal?.toFixed(2)}</p>
                                                                <p>{CkgFatTotal?.toFixed(2)}</p>
                                                                <p>{CkgSnfTotal?.toFixed(2)}</p>
                                                            </div>
                                                            <div className="reconcillationReport__table__totalBuffalo" key={ind}>
                                                                <p style={{ width: "69%" }}></p>
                                                                <p>BM</p>
                                                                <p>{BWeightTotal?.toFixed(2)}</p>
                                                                <p>{BAvgFatTotal?.toFixed(2)}</p>
                                                                <p>{BAvgSnfTotal?.toFixed(2)}</p>
                                                                <p>{BkgFatTotal?.toFixed(2)}</p>
                                                                <p>{BkgSnfTotal?.toFixed(2)}</p>
                                                            </div>
                                                        </>
                                                    );
                                                })}</>

                                            <div className="reconcillationReport__table__belowcontent1">
                                                <p><b>{val?.parentOuName}</b></p>
                                                <p style={{ width: "42%" }}></p>
                                                <p>CM</p>
                                                <p>{CWeightAgentTotal?.toFixed(2)}</p>
                                                <p>{(CAvgFatAgentTotal/CAvgFatcounter)?.toFixed(2)}</p>
                                                <p>{(CAvgSnfAgentTotal/CAvgSnfcounter)?.toFixed(2)}</p>
                                                <p>{CkgFatAgentTotal?.toFixed(2)}</p>
                                                <p>{CkgSnfAgentTotal?.toFixed(2)}</p>
                                            </div>
                                            <div className="reconcillationReport__table__belowcontent2">
                                                <p style={{ width: "69%" }}></p>
                                                <p>BM</p>
                                                <p>{BWeightAgentTotal?.toFixed(2)}</p>
                                                <p>{(BAvgFatAgentTotal/BAvgFatcounter)?.toFixed(2)}</p>
                                                <p>{(BAvgSnfAgentTotal/BAvgSnfcounter)?.toFixed(2)}</p>
                                                <p>{BkgFatAgentTotal?.toFixed(2)}</p>
                                                <p>{BkgSnfAgentTotal?.toFixed(2)}</p>
                                            </div>

                                            <div className="reconcillationReport__table__belowcontent3">
                                                <p style={{ width: "10%" }}></p>
                                                <p>Total: BM + CM</p>
                                                <p style={{ width: "55%" }}></p>
                                                <p>{BMCMWeightTotal?.toFixed(2)}</p>
                                                <p style={{ width: "50%" }}></p>
                                                <p>{BMCMKgFatTotal?.toFixed(2)}</p>
                                                <p>{BMCMKgSnfTotal?.toFixed(2)}</p>
                                            </div>

                                        </>
                                    )
                                })}


                                <div className="reconcillationReport__table__footer">
                                    <p style={{ width: "10%" }}></p>
                                    <p>Grand Total : </p>
                                    <p style={{ width: "55%" }}></p>
                                    <p>{grandWeightTotal.toFixed(2)}</p>
                                    <p style={{ width: "50%" }}></p>
                                    <p>{grandKgFatTotal.toFixed(2)}</p>
                                    <p>{grandKgSnfTotal.toFixed(2)}</p>
                                </div>
                            </div>
                        </div>
                    ) : (
                        <div className="empty_data">
                            <Paper elevation={3}>
                                <h1>No Data Available</h1>
                                <h3>For This Record.</h3>
                            </Paper>
                        </div>

                    )}
                </div >
            ) : (
                <Navigate to={"/"} />
            )}
        </>
    );
};

export default ReconcillationReport;
