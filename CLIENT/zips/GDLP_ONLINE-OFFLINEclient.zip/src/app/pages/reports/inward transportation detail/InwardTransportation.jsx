import React, { useEffect, useState, useRef } from 'react'
import { useNavigate } from "react-router-dom";
import { IconButton, Paper, Select } from "@mui/material";
import {
    CTable,
    CPagination,
    CPaginationItem,
    CForm,
    CRow,
    CCol,
    CFormLabel,
    CFormSelect,
    CFormInput,
    CButton,
} from "@coreui/react";
import images from "../../../../assets/images/log_out.png";
import { DownloadTableExcel } from 'react-export-table-to-excel';
import Header from '../../../components/header/Header';
import Loader from "../../../components/loader";
import * as XLSX from "xlsx";
import download from "../../../../assets/images/icons/download.png";
import moment from 'moment';
import { GetInwardTransportation } from '../../../utils/apiCalls';

const columns = [
    {
        key: "sn",
        label: "#",
        _props: { scope: "col" },
    },
    {
        key: "vehicleno",
        label: "Vehicle Reg. No.",
        _props: { scope: "col" },
    },
    {
        key: "transporter",
        label: "Transporter Name",
        _props: { scope: "col" },
    },
    {
        key: "milkquantity",
        label: "Milk Quantity",
        _props: { scope: "col" },
    },
    {
        key: "route",
        label: "Route Name",
        _props: { scope: "col" },
    },
    {
        key: "payterm",
        label: "Payment Term",
        _props: { scope: "col" },
    },
    {
        key: "rate",
        label: "Rate",
        _props: { scope: "col" },
    },
    {
        key: "payamount",
        label: "Payment Amount",
        _props: { scope: "col" },
    },
    {
        key: "perltrcost",
        label: "Per LTR Cost",
        _props: { scope: "col" },
    },

];


const InwardTransportation = () => {

    const [inwardData, setInwardData] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const items = [];
    const excelitem = [];
    const navigate = useNavigate();

    useEffect(() => {
        getInwardTransportation()
    }, [])
    const getInwardTransportation = () => {
        setIsLoading(true)
        const startDate = localStorage.getItem("startDate");
        const endDate = localStorage.getItem("endDate");
        // const dateParts = dateRange?.split(" - ");
        const payload = {
            startDate: localStorage.getItem("startDate"),
            endDate: localStorage.getItem("endDate"),
            bmcId: localStorage.getItem("BMCId"),
        };
        GetInwardTransportation((res) => {
            setInwardData(res.data);
            if (res.status == 200) {
                setIsLoading(false);
            }
        }, payload);
    };

    {
        inwardData?.map((val, ind) => {

            console.log("totalmilkCollection: ",val.totalMilkCollections," payAmount:",val.contract?.PayAmount);

            let paymentAmount;

            if (val.contract?.PayTerms == "Day Wise") {
                paymentAmount =
                    (val.totalMilkCollections * parseInt(val.contract?.PayAmount)) / 2;
            }
            if (val.contract?.PayTerms == "Shift Wise") {
                paymentAmount =
                    val.totalMilkCollections * parseInt(val.contract?.PayAmount)
            }
            if (val.contract?.PayTerms == "Month Wise") {
                paymentAmount =
                    (val.totalMilkCollections * parseInt(val.contract?.PayAmount)) /
                    val.daysCount;
            }

            let perltercost = paymentAmount / val.totalMilk;
            console.log("perltercost:", perltercost);

            // console.log(perltercost.toFixed(2));

            items.push({
                sn: ind + 1,
                vehicleno: val?.contract?.VehicleId?.RegistrationNo ? val.contract.VehicleId.RegistrationNo : '-',
                transporter: val?.contract?.TransporterId?.FirmName ? val.contract.TransporterId.FirmName : '-',
                route: val?.routId?.RouteName ? val.routId.RouteName : '-',
                milkquantity: val.totalMilk <= 0 ? '-' : val.totalMilk,
                payterm: val?.contract?.PayTerms ? val.contract.PayTerms : '-',
                rate: val?.contract?.PayAmount ? parseInt(val.contract.PayAmount) : '-',
                payamount: paymentAmount && paymentAmount > 0 ? paymentAmount : '-',
                perltrcost: isNaN(perltercost) || perltercost <= 0 ? '-' : `${perltercost.toFixed(2)} per LTR`
            });
            excelitem.push({
                'SlNo': ind + 1,
                'Vehicle No.': val?.milkType ? val?.milkType : " ",
                'Transporter Name': val?.organizationUnitId,
                'Milk Quantity': val?.organizationUnitName ? val?.organizationUnitName : " ",
                'Payment Term': val?.fat?.toFixed(1) ? val?.fat?.toFixed(1) : " ",
                'Payment Amount': val?.snf?.toFixed(1) ? val?.snf?.toFixed(1) : " ",
            })
        });
    }

    // console.log('This is items', items);


    const handleExportToExcel = () => {
        const workbook = XLSX.utils.book_new();
        const worksheet = XLSX.utils.json_to_sheet(excelitem);
        XLSX.utils.book_append_sheet(workbook, worksheet, "Sheet1");
        XLSX.writeFile(workbook, `inward transport details.xlsx`);
    };


    const handleInward = () => {
        navigate("/inward-transportation-form");
    };

    return (
        <div className="milk-collection">
            <div className="milk-collection__container">
                <div className="milk-collection__header">
                    <div className="milk-collection__header__section">
                        <div className="milk-collection__header__section__main">
                            <h5>Company: Ganga Dairy Pvt Ltd</h5>
                            <h4>Inward Transportation details</h4>
                        </div>
                        <div className="milk-collection__header__section__bottom">
                            <Header />
                        </div>
                    </div>
                </div>
                {isLoading ? (
                    <Loader />
                ) : (
                    <>
                        <div className="milk-collection__table">
                            <div className="milk-collection__table__header">
                                <div className="milk-collection__table__header__section">
                                    {/* <input
                                            type="text"
                                            className="form-control"
                                            placeholder="Search"
                                            value={searchTerm}
                                            onChange={handleSearch}
                                            onKeyPress={(e) => {
                                                if (e.target.value.length === 0 && e.key === " ") {
                                                    e.preventDefault();
                                                }
                                            }}
                                            onKeyDown={(e) => {
                                                if (
                                                    e.target.value.length > 1 &&
                                                    e.key === " " &&
                                                    e.target.value[e.target.value.length - 1] === " "
                                                ) {
                                                    e.preventDefault();
                                                }
                                            }}
                                        /> */}
                                </div>
                            </div>
                            <div className="back">
                                <IconButton onClick={handleInward}>
                                    <img src={images} alt="back" />
                                </IconButton>
                            </div>
                            <div className="buttonsExcel">
                                <CButton
                                    onClick={handleExportToExcel}
                                    style={{ backgroundColor: "#0e419d" }}
                                >Export to excel </CButton>
                            </div>
                            <div
                                className="milk-collection__table__body"
                                style={{ height: "75vh", overflowY: "scroll" }}
                            >
                                <CTable
                                    // ref={t   ableRef}
                                    columns={columns}
                                    items={items}
                                    hover
                                    className="striped-table"
                                />
                            </div>
                        </div>
                    </>
                )}
            </div>
        </div>
    )
}
export default InwardTransportation