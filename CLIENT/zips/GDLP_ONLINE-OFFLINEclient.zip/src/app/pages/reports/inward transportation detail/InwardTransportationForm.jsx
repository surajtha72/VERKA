import { CTable, CFormSelect, CFormInput } from "@coreui/react";
import React, { useState, useEffect } from "react";
import { CPagination, CPaginationItem } from "@coreui/react";
import { GetBillingCycle, GetDropDownOrganization } from "../../../utils/apiCalls";
import { Link, Navigate, useNavigate } from "react-router-dom";
import Header from "../../../components/header/Header";
import Confirm from "../../../components/confirmModal/confirm";
import moment from "moment";

const columns = [
  {
    key: "heading_1",
    label: "BMC",
    _props: { scope: "col" },
  },
  {
    key: "heading_2",
    label: "Start Date",
    _props: { scope: "col" },
  },
  {
    key: "heading_3",
    label: "End Date",
    _props: { scope: "col" },
  },
  {
    key: "heading_4",
    label: " ",
    _props: { scope: "col" },
  },
];

const InwardTransportationForm = () => {
  const token = localStorage.getItem("token");
  const items = [];
  const [cycleTableData, setCycleTableData] = useState([]);
  const [selectorganizationData, setSelectorganizationData] = useState([]);
  const [selectedOption, setSelectedOption] = useState(0);
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndtDate] = useState("");
  const [sessionOk, setSessionOk] = useState(false);
  const [showConfirmModal1, setShowConfirmModal1] = useState(false);
  const [alertText, setAlertText] = useState("");
  const navigate = useNavigate();
  const [orgName, setOrgName] = useState('');
  const currentDate = moment(new Date()).format('YYYY-MM-DD')
  useEffect(() => {
    getCycle();
  }, [currentDate]);

  const orgType = 5;
  useEffect(() => {
    getDropdownOrganization();
  }, [orgType]);

  const getDropdownOrganization = () => {
    GetDropDownOrganization((res) => {
      let { status, data, message } = res;
      if (status === 200) {
        setSelectorganizationData(data);
      } else if (status === 403) {
        setAlertText("You don't have access to perform this operation");
        setShowConfirmModal1(true);
      } else if (status === 500) {
        setAlertText("Something wrong happened in API");
        setShowConfirmModal1(true);
      } else if (message.includes("Invalid access token")) {
        setAlertText("User Session has Expired");
        setShowConfirmModal1(true);
        setSessionOk(true);
      }
    }, orgType);
  };
  const getCycle = () => {
    GetBillingCycle((result) => {
      setCycleTableData(result.data);
    }, currentDate);
  };

  const newData = cycleTableData?.map((item, ind) => {
    return {
      ...item,
      appendDate: `${moment(startDate).format('YYYY-MM-DD')} - ${moment(endDate).format('YYYY-MM-DD')
        }`,
    };
  });

  const handleConfirm = () => {
    setShowConfirmModal1(false)
    if (sessionOk) {
      localStorage.clear();
      navigate("/");
    }
  };

  {
    items?.push({
      heading_1: (
        <CFormSelect
          size="sm"
          onChange={(e) => {
            setSelectedOption(e.target.value);
            setOrgName(selectorganizationData?.find((org) => org.id == e.target.value)?.name);
          }}
        >
          <option value={0}>Select BMC</option>
          {selectorganizationData?.length &&
            selectorganizationData?.map((option, index) => {
              return (
                <option key={index} value={option.id}>
                  {option.name}
                </option>
              );
            })}
        </CFormSelect>
      ),
      heading_2: (
        <CFormInput
        type="date"
          size="sm"
          onChange={(e) => {
            setStartDate(e.target.value);
            // console.log(e.target.value)
          }}
        />
      ),
      heading_3: (
        <CFormInput
        type="date"
          size="sm"
          onChange={(e) => {
            setEndtDate(e.target.value);
            // console.log(e.target.value)
          }}
        />
      ),
      heading_4: (
        <div style={{ display: "flex", flexDirection: "column" }}>
          <Link to={`/inward-transportation`}>
            <span
              style={{ color: "blue", cursor: "pointer" }}
              onClick={() => {
                navigateToCycle();
              }}
            >
              Submit
            </span>
          </Link>
        </div>
      ),
    });
  }

  const navigateToCycle = () => {
    localStorage.setItem("startDate", startDate);
    localStorage.setItem("endDate", endDate);
    localStorage.setItem("BMCId", selectedOption);
    localStorage.setItem("orgName", orgName);
  };

  return (
    <>
      {token ? <div className="cyclebmc">
        <div className="cyclebmc__container">
          <div className="cyclebmc__header">
            <div className="cyclebmc__header__section">
              <div className="cyclebmc__header__section__main">
                <h5>Company: Ganga Dairy Pvt Ltd</h5>
                <h4>{`${"Inward Transportation"}`}</h4>
              </div>
              <div className="cyclebmc__header__section__bottom">
                <Header />
              </div>
            </div>
          </div>
          <div className="cyclebmc__table">
            <div
              className="cyclebmc__table__body"
              style={{ height: "70vh", overflowY: "scroll" }}
            >
              <CTable
                columns={columns}
                items={items}
                hover
                className="striped-table" />
            </div>
          </div>
        </div>
        {showConfirmModal1 && (
          <Confirm
            buttonText={"OK"}
            isCancelRequired={false}
            confirmTitle={alertText}
            onConfirm={() => {
              handleConfirm();
            }}
            onCancel={() => {
              setShowConfirmModal1(false);
              setSessionOk(true);
            }}
          />
        )}
      </div> : <Navigate to={"/"} />
      }
    </>
  );
};

export default InwardTransportationForm;
